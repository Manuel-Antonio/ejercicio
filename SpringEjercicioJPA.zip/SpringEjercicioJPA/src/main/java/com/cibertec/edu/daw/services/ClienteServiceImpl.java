package com.cibertec.edu.daw.services;

import com.cibertec.edu.daw.models.Cliente;

public interface ClienteServiceImpl {
	public Cliente saveCliente(Cliente cliente);
	public Cliente updateCliente(Cliente cliente);
	public Cliente obtenerClienteByCorreo(String correo);	
	public Cliente obtenerClienteById(long id);
}
