package com.cibertec.edu.daw.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cibertec.edu.daw.models.DetalleFactura;
import com.cibertec.edu.daw.repositories.DetalleFacturaRepository;

@Service
public class DetalleFacturaService implements DetalleFacturaServiceImpl{
	@Autowired
	private DetalleFacturaRepository detalleFacturaRepository;
	
	@Override
	public DetalleFactura saveDetallefactura(DetalleFactura detalleFactura) {
		try {
			DetalleFactura saveDetallefactura = detalleFacturaRepository.save(detalleFactura);
			return saveDetallefactura;
		} catch (Exception e) {
			throw e;
		}
	}

}
