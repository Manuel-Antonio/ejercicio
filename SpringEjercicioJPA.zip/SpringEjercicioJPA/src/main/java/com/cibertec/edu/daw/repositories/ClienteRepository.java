package com.cibertec.edu.daw.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cibertec.edu.daw.models.Cliente;



public interface ClienteRepository extends CrudRepository<Cliente, Long> {
	@Query("select cli from Cliente cli where cli.correo = :correo")
    public Cliente obtenerClientePorCorreo(@Param("correo") String correo);
}
