package com.cibertec.edu.daw.repositories;


import org.springframework.data.repository.CrudRepository;
import com.cibertec.edu.daw.models.DetalleFactura;

public interface DetalleFacturaRepository  extends CrudRepository<DetalleFactura, Long>{

}
