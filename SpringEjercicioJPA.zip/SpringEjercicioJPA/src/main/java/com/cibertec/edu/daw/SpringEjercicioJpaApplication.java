package com.cibertec.edu.daw;

import java.util.Date;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.cibertec.edu.daw.controllers.ClienteController;
import com.cibertec.edu.daw.controllers.DetalleFacturaController;
import com.cibertec.edu.daw.controllers.FacturaController;
import com.cibertec.edu.daw.models.Cliente;
import com.cibertec.edu.daw.models.DetalleFactura;
import com.cibertec.edu.daw.models.Factura;

@SpringBootApplication
public class SpringEjercicioJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEjercicioJpaApplication.class, args);
	}

	@Bean
	public CommandLineRunner testMain(
			DetalleFacturaController detalleFacturaController, 
			FacturaController facturaController,
			ClienteController clienteController
			) {
		return args -> {
			Cliente cli = new Cliente();
			
			cli.setNombre("Manuel");
			cli.setCorreo("correo@correo.com");
			
			cli = clienteController.saveCliente(cli);
			
			Factura fac = new Factura();
			fac.setFechaEmision(new Date());
			fac.setCliente(cli);
			
			fac = facturaController.saveFactura(fac);
			
			DetalleFactura detfac = new DetalleFactura();
			detfac.setCantidad(10);
			detfac.setPrecioUnitario(12);
			detfac.setProducto("Zapatilla Nike");
			detfac.setFactura(fac);
			
			detfac = detalleFacturaController.saveDetallefactura(detfac);
		};
	}
}
