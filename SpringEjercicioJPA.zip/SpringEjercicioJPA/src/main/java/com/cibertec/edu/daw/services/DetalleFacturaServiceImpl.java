package com.cibertec.edu.daw.services;

import com.cibertec.edu.daw.models.DetalleFactura;

public interface DetalleFacturaServiceImpl {
	public DetalleFactura saveDetallefactura(DetalleFactura detalleFactura);
}
