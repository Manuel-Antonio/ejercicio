package com.cibertec.edu.daw.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cibertec.edu.daw.models.Cliente;
import com.cibertec.edu.daw.repositories.ClienteRepository;

@Service
public class ClienteService implements ClienteServiceImpl{
	@Autowired
	private ClienteRepository clienteRepository;

	@Override
	public Cliente saveCliente(Cliente cliente) {
		try {
			Cliente saveCliente = clienteRepository.save(cliente);
			return saveCliente;
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public Cliente obtenerClienteByCorreo(String correo) {
		try {
			Cliente cli = clienteRepository.obtenerClientePorCorreo(correo);
			return cli;
		} catch (Exception e) {
			throw e;
		}

	}

	@Override
	public Cliente obtenerClienteById(long id) {
		try {
			Cliente cli = clienteRepository.findById(id).get();
			return cli;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Cliente updateCliente(Cliente cliente) {
		try {
			Cliente cli = clienteRepository.save(cliente);
			return cli;
		} catch (Exception e) {
			throw e;
		}
	}
	
	
}
