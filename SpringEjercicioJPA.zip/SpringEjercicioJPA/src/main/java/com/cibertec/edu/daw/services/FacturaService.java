package com.cibertec.edu.daw.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cibertec.edu.daw.models.DetalleFactura;
import com.cibertec.edu.daw.models.Factura;
import com.cibertec.edu.daw.repositories.FacturaRepository;

@Service
public class FacturaService implements FacturaServiceImpl{
	@Autowired
	private FacturaRepository facturaRepository;
	@Override
	public Factura saveFactura(Factura factura) {
		try {
			Factura saveFactura = facturaRepository.save(factura);
			return saveFactura;
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public Factura obtenerFacturaByNumero(long numero) {
		try {
			Factura saveFactura = facturaRepository.obtenerFacturaPorNumero(numero);
			return saveFactura;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public List<DetalleFactura> obtenerDetalleFactura(long numero) {
		try {
			List<DetalleFactura> lista = new ArrayList<DetalleFactura>();
			lista = obtenerFacturaByNumero(numero).getDetalleFactura();
			return lista;
		} catch (Exception e) {
			throw e;
		}
		
	}

}
