package com.cibertec.edu.daw.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cibertec.edu.daw.models.Cliente;
import com.cibertec.edu.daw.services.ClienteServiceImpl;

@Controller
public class ClienteController {
	@Autowired
	private ClienteServiceImpl  clienteServiceImpl;
	
	
	public Cliente saveCliente(Cliente cliente) {
		// Validar correo unico
		Cliente cli = clienteServiceImpl.obtenerClienteByCorreo(cliente.getCorreo());
		if(cli != null) {
			return null;
		}
		
		return clienteServiceImpl.saveCliente(cliente);
	}
	
	public Cliente updateCliente(Cliente cliente) {
		// Validar existencia de cliente
		Cliente cli = clienteServiceImpl.obtenerClienteById(cliente.getId());
		if(cli == null) {
			return null;
		}
		// Validar correo unico
		cli = clienteServiceImpl.obtenerClienteByCorreo(cliente.getCorreo());
		if(cli != null) {
			return null;
		}
		return clienteServiceImpl.updateCliente(cliente);
	}
	
}
