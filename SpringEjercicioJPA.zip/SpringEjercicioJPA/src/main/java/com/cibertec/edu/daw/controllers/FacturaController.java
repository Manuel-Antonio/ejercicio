package com.cibertec.edu.daw.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import com.cibertec.edu.daw.models.Cliente;
import com.cibertec.edu.daw.models.DetalleFactura;
import com.cibertec.edu.daw.models.Factura;
import com.cibertec.edu.daw.services.ClienteServiceImpl;
import com.cibertec.edu.daw.services.FacturaServiceImpl;

@Controller
public class FacturaController {

	@Autowired
	private FacturaServiceImpl facturaServiceImpl;
	
	@Autowired
	private ClienteServiceImpl  clienteServiceImpl;
	
	public Factura saveFactura(Factura factura) {
		// Validar existencia de cliente
		Cliente cli = clienteServiceImpl.obtenerClienteById(factura.getCliente().getId());
		if(cli == null) {
			return null;
		}
		// Creando un numero de factura unico
		factura.setNumero(System.currentTimeMillis());
		// Guardando la factura
		return facturaServiceImpl.saveFactura(factura);
	}
	
	public List<DetalleFactura> obtenerDetalleFactura(long numero) {
		
		Factura fac = facturaServiceImpl.obtenerFacturaByNumero(numero);
		if(fac == null) {
			return null;
		}
		return facturaServiceImpl.obtenerDetalleFactura(numero);
	}
	
	
	
}
