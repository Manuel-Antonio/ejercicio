package com.cibertec.edu.daw.services;

import java.util.List;

import com.cibertec.edu.daw.models.DetalleFactura;
import com.cibertec.edu.daw.models.Factura;

public interface FacturaServiceImpl {
	public Factura saveFactura(Factura factura);
	public Factura obtenerFacturaByNumero(long numero);
	public List<DetalleFactura> obtenerDetalleFactura(long numero);
}
