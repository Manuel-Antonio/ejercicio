package com.cibertec.edu.daw.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cibertec.edu.daw.models.DetalleFactura;
import com.cibertec.edu.daw.models.Factura;
import com.cibertec.edu.daw.services.DetalleFacturaServiceImpl;
import com.cibertec.edu.daw.services.FacturaServiceImpl;

@Controller
public class DetalleFacturaController {
	@Autowired
	private FacturaServiceImpl facturaServiceImpl;
	
	@Autowired
	private DetalleFacturaServiceImpl detalleFacturaServiceImpl;
	
	public DetalleFactura saveDetallefactura(DetalleFactura detalleFactura) {
		Factura fac = facturaServiceImpl.obtenerFacturaByNumero(detalleFactura.getFactura().getNumero());
		if(fac == null) {
			return null;
		}
		return detalleFacturaServiceImpl.saveDetallefactura(detalleFactura);
	}
	
	
}
