package com.cibertec.edu.daw.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cibertec.edu.daw.models.Factura;

public interface FacturaRepository  extends CrudRepository<Factura, Long>{
	@Query("select fac from Factura fac where fac.numero = ?1")
	public Factura obtenerFacturaPorNumero(@Param("numero") long numero);
	
	
}
