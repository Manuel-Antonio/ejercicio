package com.cibertec.edu.daw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEjercicioJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
